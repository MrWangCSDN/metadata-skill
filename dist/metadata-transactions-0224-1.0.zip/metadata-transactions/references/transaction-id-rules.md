# 交易码验证规则

本文档详细说明 flowtran 交易码的格式规范、验证规则和示例。

## 交易码格式规范

### 基本格式

**格式**: T + (C/D/G/Y) + 4位数字(共6位)

**组成**:
1. 固定前缀: `T`
2. 领域标识: `C`/`D`/`G`/`Y`
3. 数字编码: 4位数字

**示例**: `TC021`, `TY001`, `TD250`, `TG350`

### 领域划分

| 领域前缀 | 完整格式 | 数字范围 | 领域名称 | 示例 |
|---------|---------|---------|---------|------|
| **TC** | TC021-TC999 | 021-999 | 对公分布式核心存款领域 | TC021, TC100, TC999 |
| **TD** | TD001-TD499 | 001-499 | 对公分布式核心贷款领域 | TD001, TD100, TD499 |
| **TG** | TG001-TG499 | 001-499 | 对公分布式核心结算领域 | TG001, TG100, TG499 |
| **TY** | TY001-TY999 | 001-999 | 对公分布式核心平台公共领域 | TY001, TY291, TY999 |

## 详细验证规则

### TC 开头 - 存款领域

**规则**: T + C + 021~999 的数字

**有效范围**:
- 最小值: TC021
- 最大值: TC999
- 总数量: 979 个可用编码

**有效示例**:
```
✅ TC021 - 最小有效编码
✅ TC100 - 常用编码
✅ TC500 - 中间编码
✅ TC999 - 最大有效编码
```

**无效示例**:
```
❌ TC001 - 小于最小值 TC021
❌ TC020 - 小于最小值 TC021
❌ TC1000 - 超过4位数字
❌ C021 - 缺少 T 前缀
❌ tc100 - 必须大写
```

### TD 开头 - 贷款领域

**规则**: T + D + 001~499 的数字

**有效范围**:
- 最小值: TD001
- 最大值: TD499
- 总数量: 499 个可用编码

**有效示例**:
```
✅ TD001 - 最小有效编码
✅ TD100 - 常用编码
✅ TD250 - 中间编码
✅ TD499 - 最大有效编码
```

**无效示例**:
```
❌ TD000 - 小于最小值 TD001
❌ TD500 - 超过最大值 TD499
❌ TD999 - 超过最大值 TD499
❌ D100 - 缺少 T 前缀
```

### TG 开头 - 结算领域

**规则**: T + G + 001~499 的数字

**有效范围**:
- 最小值: TG001
- 最大值: TG499
- 总数量: 499 个可用编码

**有效示例**:
```
✅ TG001 - 最小有效编码
✅ TG100 - 常用编码
✅ TG250 - 中间编码
✅ TG499 - 最大有效编码
```

**无效示例**:
```
❌ TG000 - 小于最小值 TG001
❌ TG500 - 超过最大值 TG499
❌ G100 - 缺少 T 前缀
```

### TY 开头 - 平台公共领域

**规则**: T + Y + 001~999 的数字

**有效范围**:
- 最小值: TY001
- 最大值: TY999
- 总数量: 999 个可用编码

**有效示例**:
```
✅ TY001 - 最小有效编码
✅ TY100 - 常用编码
✅ TY291 - 常用编码
✅ TY999 - 最大有效编码
```

**无效示例**:
```
❌ TY000 - 小于最小值 TY001
❌ TY1000 - 超过4位数字
❌ Y291 - 缺少 T 前缀
```

## 验证实现

### Python 实现

```python
import re
from typing import Tuple

def validate_flowtran_id(trans_id: str) -> Tuple[bool, str]:
    """
    验证 flowtran 交易码是否符合规范
    
    Args:
        trans_id: 交易码字符串
        
    Returns:
        (是否有效, 消息/领域名称)
    """
    if not trans_id:
        return False, "交易码不能为空"
    
    if len(trans_id) != 6:
        return False, f"交易码必须是6位字符,当前: {len(trans_id)}位"
    
    # 转换为大写
    trans_id = trans_id.upper()
    
    # 检查格式: T + 1个字母 + 4个数字
    if not re.match(r'^T[CDGY]\d{4}$', trans_id):
        return False, "交易码格式必须是: T + C/D/G/Y + 4位数字"
    
    # 提取领域前缀和数字
    prefix = trans_id[1]  # C/D/G/Y
    try:
        num = int(trans_id[2:])  # 后4位数字
    except ValueError:
        return False, "交易码后4位必须是数字"
    
    # TC021-TC999
    if prefix == 'C':
        if 21 <= num <= 999:
            return True, "对公分布式核心存款领域"
        else:
            return False, f"TC开头的交易码必须在 TC021-TC999 范围内,当前: TC{num:04d}"
    
    # TD001-TD499
    elif prefix == 'D':
        if 1 <= num <= 499:
            return True, "对公分布式核心贷款领域"
        else:
            return False, f"TD开头的交易码必须在 TD001-TD499 范围内,当前: TD{num:04d}"
    
    # TG001-TG499
    elif prefix == 'G':
        if 1 <= num <= 499:
            return True, "对公分布式核心结算领域"
        else:
            return False, f"TG开头的交易码必须在 TG001-TG499 范围内,当前: TG{num:04d}"
    
    # TY001-TY999
    elif prefix == 'Y':
        if 1 <= num <= 999:
            return True, "对公分布式核心平台公共领域"
        else:
            return False, f"TY开头的交易码必须在 TY001-TY999 范围内,当前: TY{num:04d}"
    
    else:
        return False, f"交易码必须以 TC/TD/TG/TY 开头,当前: T{prefix}"


def extract_domain_prefix(trans_id: str) -> str:
    """提取领域前缀 (C/D/G/Y)"""
    trans_id = trans_id.upper()
    if len(trans_id) >= 2 and trans_id[0] == 'T':
        return trans_id[1]
    return ""
```

### JavaScript/TypeScript 实现

```typescript
interface ValidationResult {
    valid: boolean;
    message: string;
}

function validateFlowtranId(transId: string): ValidationResult {
    if (!transId) {
        return { 
            valid: false, 
            message: "交易码不能为空" 
        };
    }
    
    if (transId.length !== 6) {
        return { 
            valid: false, 
            message: `交易码必须是6位字符,当前: ${transId.length}位` 
        };
    }
    
    // 转换为大写
    transId = transId.toUpperCase();
    
    // 检查格式
    if (!/^T[CDGY]\d{4}$/.test(transId)) {
        return { 
            valid: false, 
            message: "交易码格式必须是: T + C/D/G/Y + 4位数字" 
        };
    }
    
    const prefix = transId[1];  // C/D/G/Y
    const num = parseInt(transId.substring(2));
    
    switch (prefix) {
        case 'C':
            if (num >= 21 && num <= 999) {
                return { 
                    valid: true, 
                    message: "对公分布式核心存款领域" 
                };
            }
            return { 
                valid: false, 
                message: `TC开头的交易码必须在 TC021-TC999 范围内,当前: TC${num.toString().padStart(4, '0')}` 
            };
            
        case 'D':
            if (num >= 1 && num <= 499) {
                return { 
                    valid: true, 
                    message: "对公分布式核心贷款领域" 
                };
            }
            return { 
                valid: false, 
                message: `TD开头的交易码必须在 TD001-TD499 范围内,当前: TD${num.toString().padStart(4, '0')}` 
            };
            
        case 'G':
            if (num >= 1 && num <= 499) {
                return { 
                    valid: true, 
                    message: "对公分布式核心结算领域" 
                };
            }
            return { 
                valid: false, 
                message: `TG开头的交易码必须在 TG001-TG499 范围内,当前: TG${num.toString().padStart(4, '0')}` 
            };
            
        case 'Y':
            if (num >= 1 && num <= 999) {
                return { 
                    valid: true, 
                    message: "对公分布式核心平台公共领域" 
                };
            }
            return { 
                valid: false, 
                message: `TY开头的交易码必须在 TY001-TY999 范围内,当前: TY${num.toString().padStart(4, '0')}` 
            };
            
        default:
            return { 
                valid: false, 
                message: `交易码必须以 TC/TD/TG/TY 开头,当前: T${prefix}` 
            };
    }
}
```

## 错误提示模板

### 缺少 T 前缀

```
❌ 交易码验证失败: 交易码必须以 T 开头

当前: Y291
正确: TY291

💡 正确格式: T + C/D/G/Y + 4位数字
   - TC021-TC999: 存款领域
   - TD001-TD499: 贷款领域
   - TG001-TG499: 结算领域
   - TY001-TY999: 平台公共领域
```

### 领域前缀错误

```
❌ 交易码验证失败: 交易码必须以 TC/TD/TG/TY 开头

当前: TX291
正确示例: TY291

💡 有效的领域前缀:
   - TC: 存款领域 (C021-C999)
   - TD: 贷款领域 (D001-D499)
   - TG: 结算领域 (G001-G499)
   - TY: 平台公共领域 (Y001-Y999)
```

### 数字范围错误

```
❌ 交易码验证失败: TC开头的交易码必须在 TC021-TC999 范围内

当前: TC001
最小值: TC021
最大值: TC999

💡 请使用 TC021-TC999 之间的编码,例如:
   ✅ TC021, TC100, TC500, TC999
```

## 交易码唯一性

### 全局唯一性要求

- ✅ **工程级唯一**: 每个交易码在整个工程中只能使用一次
- ✅ **文件命名一致**: 文件名必须与交易码对应: `{交易码}.flowtrans`
- ✅ **自动检查**: 创建前在 trans 目录下全局查找,如已存在则修改

### 检查文件是否存在

```python
import os
from pathlib import Path

def find_flowtran_file(trans_id: str, base_path: str) -> str:
    """在 trans 目录下全局查找 flowtran 文件"""
    filename = f"{trans_id}.flowtrans"
    
    # 在 trans 目录及其子目录下递归查找
    trans_dir = os.path.join(base_path, "src/main/resources/trans")
    
    for root, dirs, files in os.walk(trans_dir):
        if filename in files:
            return os.path.join(root, filename)
    
    return None  # 未找到


def should_create_or_modify(trans_id: str, base_path: str) -> tuple[str, str]:
    """判断应该创建还是修改"""
    existing_file = find_flowtran_file(trans_id, base_path)
    
    if existing_file:
        return "modify", existing_file
    else:
        return "create", None
```

## 常见错误示例

| 错误输入 | 原因 | 正确示例 |
|---------|------|---------|
| Y291 | 缺少 T 前缀 | TY291 |
| ty291 | 小写字母 | TY291 |
| TC001 | TC 范围错误 | TC021 |
| TD500 | TD 范围错误 | TD499 |
| TX100 | 无效前缀 X | TC100 或 TY100 |
| T100 | 缺少领域标识 | TC100 |
| TC10 | 数字不足4位 | TC0010 |

## 测试用例

```python
def test_valid_flowtran_ids():
    """测试有效的交易码"""
    valid_cases = [
        # TC 开头
        ("TC021", True, "对公分布式核心存款领域"),
        ("TC100", True, "对公分布式核心存款领域"),
        ("TC500", True, "对公分布式核心存款领域"),
        ("TC999", True, "对公分布式核心存款领域"),
        
        # TD 开头
        ("TD001", True, "对公分布式核心贷款领域"),
        ("TD100", True, "对公分布式核心贷款领域"),
        ("TD250", True, "对公分布式核心贷款领域"),
        ("TD499", True, "对公分布式核心贷款领域"),
        
        # TG 开头
        ("TG001", True, "对公分布式核心结算领域"),
        ("TG100", True, "对公分布式核心结算领域"),
        ("TG250", True, "对公分布式核心结算领域"),
        ("TG499", True, "对公分布式核心结算领域"),
        
        # TY 开头
        ("TY001", True, "对公分布式核心平台公共领域"),
        ("TY100", True, "对公分布式核心平台公共领域"),
        ("TY291", True, "对公分布式核心平台公共领域"),
        ("TY999", True, "对公分布式核心平台公共领域"),
    ]
    
    for trans_id, expected_valid, expected_msg in valid_cases:
        is_valid, message = validate_flowtran_id(trans_id)
        assert is_valid == expected_valid, f"Failed for {trans_id}"
        assert message == expected_msg, f"Wrong message for {trans_id}"


def test_invalid_flowtran_ids():
    """测试无效的交易码"""
    invalid_cases = [
        # 格式错误
        ("", False),                # 空字符串
        ("T", False),               # 太短
        ("TC", False),              # 太短
        ("TC12", False),            # 太短
        ("TC12345", False),         # 太长
        
        # 前缀错误
        ("Y291", False),            # 缺少 T
        ("C021", False),            # 缺少 T
        ("TY", False),              # 缺少数字
        ("TX100", False),           # X 不是有效前缀
        
        # TC 范围错误
        ("TC001", False),           # 小于 TC021
        ("TC020", False),           # 小于 TC021
        
        # TD 范围错误
        ("TD000", False),           # 小于 TD001
        ("TD500", False),           # 大于 TD499
        ("TD999", False),           # 大于 TD499
        
        # TG 范围错误
        ("TG000", False),           # 小于 TG001
        ("TG500", False),           # 大于 TG499
        
        # TY 范围错误
        ("TY000", False),           # 小于 TY001
    ]
    
    for trans_id, expected_valid in invalid_cases:
        is_valid, _ = validate_flowtran_id(trans_id)
        assert is_valid == expected_valid, f"Failed for '{trans_id}'"
```

## 快速参考

### 验证流程清单

- [ ] 检查交易码不为空
- [ ] 检查长度为6位
- [ ] 转换为大写
- [ ] 检查格式(T + C/D/G/Y + 4位数字)
- [ ] 提取领域前缀
- [ ] 验证数字范围
- [ ] 返回验证结果和领域名称
